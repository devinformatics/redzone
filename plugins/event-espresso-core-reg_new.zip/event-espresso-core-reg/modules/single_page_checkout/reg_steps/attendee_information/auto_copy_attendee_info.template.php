	<p id="spco-auto-copy-attendee-pg" class="smaller-text lt-grey-text">
		<?php echo apply_filters( 'FHEE__registration_page_attendee_information__auto_copy_attendee_pg', __('The above information will be used for any additional tickets/attendees.', 'event_espresso' ));?>
	</p>