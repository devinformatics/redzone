<div class="padding">
	<dl id="additional">
		<dt><a href="https://eventespresso.com/documentation/"><?php _e('Event Espresso docs', 'event_espresso'); ?></a></dt>
			<dd><?php _e('Where you can get general Event Espresso documentation', 'event_espresso'); ?></dd>
		<dt><a href="https://eventespresso.com/support/documentation/versioned-docs/?doc_ver=ee4"><?php _e('Event Espresso 4 docs', 'event_espresso'); ?></a> </dt>
			<dd><?php _e('Where you can get Event Espresso 4-specific documentation', 'event_espresso'); ?></dd>
	</dl>
</div>