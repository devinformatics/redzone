<a class='clone-date-time dtm-inp-btn' rel='<?php echo $row; ?>' title='<?php esc_attr_e('Clone this Event Date and Time', 'event_espresso'); ?>' style='position:relative; top:5px; margin:0 0 0 10px; font-size:.9em; cursor:pointer;'>
	<img src='<?php echo EE_IMAGES_URL;?>clone-trooper-16x16.png' width='16' height='16' alt='<?php esc_attr_e('clone', 'event_espresso'); ?>'/>
</a>
