<?php /* @todo: re-implement this admin option when the staff manager exists
<h2 class="ee-admin-settings-hdr">
	<?php _e('Espresso Admin Managers', 'event_espresso'); ?>
</h2>

<table class="form-table">
	<tbody>
		<tr>
			<th>
				<label>
					<?php _e('Use the Staff Manager?', 'event_espresso'); ?>
				</label>
			</th>
			<td>
				<?php echo $use_personnel_manager_select; ?>
				<p class="description">
					<?php _e('Activates an additional Event Espresso admin page that allows you to manage event staff and personnel.', 'event_espresso'); ?>
				</p>
			</td>
		</tr>

	</tbody>
</table>
 
 */