<h4>[FNAME] [LNAME]</h4>
<ul>
	<li><strong><?php _e('Registration Code:', 'event_espresso'); ?></strong> [REGISTRATION_CODE]</li>
	<li><strong><?php _e('Tickets:', 'event_espresso'); ?></strong></li>
</ul>
<ul>[TICKET_LIST]</ul>
<strong><?php _e('Questions & Answers', 'event_espresso'); ?></strong>
<ul>[QUESTION_LIST]</ul>
<hr />
