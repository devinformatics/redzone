<p><?php _e('This content can be replaced and it will show in the generated message.', 'event_espresso'); ?></p>
