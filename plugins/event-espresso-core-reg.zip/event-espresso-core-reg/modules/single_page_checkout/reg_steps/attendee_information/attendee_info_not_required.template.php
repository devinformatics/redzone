	<p class="spco-attendee-info-not-required-pg smaller-text lt-grey-text">
		<?php echo apply_filters( 'FHEE__registration_page_attendee_information__attendee_info_not_required_pg', __( 'This ticket type does not require any information for additional attendees, so attendee #1\'s information will be used for its registration purposes.', 'event_espresso' ));?>
	</p>
