(function($) {
	
	// close a div
//	$('.close-this-lnk').click(function() {
//		$(this).parent().slideUp('fast'); 
//	});	


	//$('.fade-away').delay(8000).fadeOut();


	
})(jQuery);
