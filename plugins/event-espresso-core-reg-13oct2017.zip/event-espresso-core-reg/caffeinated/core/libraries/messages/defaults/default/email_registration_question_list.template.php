<li><strong><?php _e('Question:', 'event_espresso'); ?></strong> [QUESTION]</li>
<li><strong><?php _e('Answer:', 'event_espresso'); ?> </strong>[ANSWER]</li>
