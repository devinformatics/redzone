== Installing your Event Espresso Arabica Theme ==

1. Download a copy of the `Espresso_Arabica_2014` folder to your computer using your FTP or SFTP client.
2. Browse to the WordPress themes folder in your WordPress site. It will be located here `wp-content/themes`.
3. Upload the `Espresso_Arabica_2014` folder to the location above.
4. Login to your WordPress admin.
5. Go to Appearance & Themes.
6. Locate your Event Espresso Arabic theme and click on the Activate button.