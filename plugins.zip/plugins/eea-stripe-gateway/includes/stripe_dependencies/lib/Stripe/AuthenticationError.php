<?php

namespace EEA_Stripe;

class Stripe_AuthenticationError extends Stripe_Error
{
}
