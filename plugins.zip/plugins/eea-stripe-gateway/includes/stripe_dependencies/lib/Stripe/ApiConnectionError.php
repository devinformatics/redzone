<?php

namespace EEA_Stripe;

class Stripe_ApiConnectionError extends Stripe_Error
{
}
